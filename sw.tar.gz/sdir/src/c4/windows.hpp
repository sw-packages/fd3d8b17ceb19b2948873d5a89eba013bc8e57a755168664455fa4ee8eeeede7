#ifndef _C4_WINDOWS_HPP_
#define _C4_WINDOWS_HPP_

#ifdef C4_WIN
#include "c4/windows_push.hpp"
#include <Windows.h>
#endif

#endif /* _C4_WINDOWS_HPP_ */
